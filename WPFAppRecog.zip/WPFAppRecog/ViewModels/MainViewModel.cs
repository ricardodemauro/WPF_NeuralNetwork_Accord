﻿using Accord.Neuro;
using Accord.Neuro.ActivationFunctions;
using Accord.Neuro.Networks;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WPFAppRecog.Databases;

namespace WPFAppRecog.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private DeepBeliefNetwork _network;
        public DeepBeliefNetwork Network { get { return _network; } private set { Set(ref _network, value); } }

        private IDatabase _database;
        public IDatabase Database { get { return _database; } private set { Set(ref _database, value); } }

        private readonly IStochasticFunction _activationFunction = new BernoulliFunction();

        private int _newLayerNeurons;
        public int NewLayerNeurons { get { return _newLayerNeurons; } set { Set(ref _newLayerNeurons, value); } }

        public bool CanClassify { get { return Network != null && Database != null && Network.OutputCount == Database.Classes; } }
        public bool CanGenerate { get { return Network != null && Network.Layers.Length > 0; } }

        #region ViewModels
        public LearnViewModel Learn { get; private set; }
        #endregion ViewModels

        public MainViewModel()
        {
            Network = new DeepBeliefNetwork(_activationFunction, 1024, 50, 10);

            Database = new OptdigitsDatabase()
            {
                IsNormalized = false
            };

            new GaussianWeights(Network).Randomize();
            Network.UpdateVisibleWeights();
            NewLayerNeurons = 10;
        }

        public void Save(string filename)
        {
            Network.Save(filename);
        }

        public void Load(string filename)
        {
            Network = DeepBeliefNetwork.Load(filename);
        }

        public void StackNewLayer()
        {
            if (Database.IsNormalized && Network.Layers.Length == 0)
            {
                Network.Push(NewLayerNeurons,
                    visibleFunction: new GaussianFunction(),
                    hiddenFunction: new BernoulliFunction());
            }
            else Network.Push(NewLayerNeurons, new BernoulliFunction());

            FireEventChanged(nameof(Network));
        }

        public void RemoveLastLayer()
        {
            Network.Pop();
            FireEventChanged(nameof(Network));
        }
    }
}
