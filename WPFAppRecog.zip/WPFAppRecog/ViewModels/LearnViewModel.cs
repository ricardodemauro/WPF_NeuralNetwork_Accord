﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using WPFAppRecog.Models;

namespace WPFAppRecog.ViewModels
{
    public class LearnViewModel : ViewModelBase
    {
        public MainViewModel Main { get; set; }

        public List<Sample> Display { get; set; }

        /// <summary>Indicates whether a background thread is busy loading data.</summary>
        public bool IsDataLoading { get; set; }

        /// <summary>Indicates whether training data has already finished loading.</summary>
        public bool HasDataLoaded { get; private set; }

        /// <summary>Indicates the learning procedure is starting.</summary>
        public bool IsStarting { get; set; }

        /// <summary>Indicates the learning procedure is currently being run.</summary>
        public bool IsLearning { get; private set; }

        public bool HasLearned { get; private set; }

        public bool CanPause { get { return IsLearning; } }
        public bool CanReset { get { return Main.CanGenerate; } }
        public bool CanTest { get { return HasDataLoaded && Main.CanClassify && !IsLearning; } }


        private double _learningRate;
        public double LearningRate { get { return _learningRate; } set { Set(ref _learningRate, value); } }

        private double _momentum;
        public double Momentum { get { return _momentum; } set { Set(ref _momentum, value); } }

        private double _weightDecay;
        public double WeightDecay { get { return _weightDecay; } set { Set(ref _weightDecay, value); } }

        private int _epochs;
        public int Epochs { get { return _epochs; } set { Set(ref _epochs, value); } }

        private int _batchSize;
        public int BatchSize { get { return _batchSize; } set { Set(ref _batchSize, value); } }

        public DataType CurrentSet { get; set; }
        public DataType[] Sets { get; private set; }

        public bool CanStart
        {
            get
            {
                return (HasDataLoaded && !IsLearning);
            }
        }

        public LearnViewModel(MainViewModel mainViewModel)
        {
            Main = mainViewModel;

            LearningRate = 0.1;
            WeightDecay = 0.001;
            Momentum = 0.9;
            Epochs = 50;
            BatchSize = 100;

            if (IsDesignTime)
                HasLearned = true;
        }

        public void OpenDatabase()
        {
            IsDataLoading = true;

            Dispatcher dispatcher = Dispatcher.CurrentDispatcher;

            new Task(() =>
            {
                Main.Database.Load();

                dispatcher.BeginInvoke((Action)(() =>
                {
                    IsDataLoading = false;
                    HasDataLoaded = true;
                    UpdateDisplay();
                }));

            }).Start();
        }

        public void Start()
        {
            if (!CanStart) return;

            IsLearning = true;
            IsStarting = true;
            //shouldStop = false;

            //ErrorPoints.Points.Clear();
            //CurrentEpoch = 0;
            //CurrentError = 0;

            //if (ShouldLearnEntireNetwork)
            //    learnNetworkSupervised();

            //else if (ShouldLayerBeSupervised)
            //    learnLayerSupervised();

            //else learnLayerUnsupervised();
        }

        private void UpdateDisplay()
        {
            if (HasDataLoaded)
            {
                List<Sample> dataset = CurrentSet == DataType.Training ? Main.Database.Training : Main.Database.Testing;
                Display = dataset;
            }
        }
    }
}
